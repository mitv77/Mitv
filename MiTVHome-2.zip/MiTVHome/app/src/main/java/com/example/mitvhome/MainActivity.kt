package com.example.mitvhome

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.tv.TvContract
import android.media.tv.TvInputInfo
import android.media.tv.TvInputManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.content.pm.ResolveInfo
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
private val PS5_REGEX = Regex("ps\\s?5|playstation", RegexOption.IGNORE_CASE)
private fun isPs5(name: String) = PS5_REGEX.containsMatchIn(name)

class MainActivity : Activity() {

    private val INK = Color.parseColor("#F1EBE0")
    private val DIM = Color.parseColor("#8C887F")
    private val GOLD = Color.parseColor("#E8BB72")
    private val NAVY = Color.parseColor("#0A1640")

    private val handler = Handler(Looper.getMainLooper())
    private val clockTick = object : Runnable {
        override fun run() {
            updateClock()
            handler.postDelayed(this, 15_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    override fun onResume() {
        super.onResume()
        handler.post(clockTick)
        loadInputs()
        loadApps()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(clockTick)
    }

    private fun Int.dp(): Int = (this * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun updateClock() {
        val now = Date()
        findViewById<TextView>(R.id.clock).text = SimpleDateFormat("h:mm", Locale.getDefault()).format(now)
        findViewById<TextView>(R.id.date).text = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now)
    }

    // ---------- Inputs (HDMI, AV, etc. from TvInputManager) ----------

    private fun loadInputs() {
        val row = findViewById<LinearLayout>(R.id.inputsContainer)
        row.removeAllViews()
        val tvm = getSystemService(TV_INPUT_SERVICE) as TvInputManager
        val inputs = tvm.tvInputList
            .filter { it.isPassthroughInput }
            .sortedByDescending { isPs5(it.loadLabel(this).toString()) }

        if (inputs.isEmpty()) {
            row.addView(label("No inputs found", 18f, false, DIM))
            return
        }
        for (info in inputs) {
            val name = info.loadLabel(this).toString()
            val connected = tvm.getInputState(info.id) == TvInputManager.INPUT_STATE_CONNECTED
            row.addView(inputCard(info, name, connected))
        }
    }

    private fun inputCard(info: TvInputInfo, name: String, connected: Boolean): View {
        val ps5 = isPs5(name)
        val card = baseCard(if (ps5) 340.dp() else 220.dp(), 150.dp())
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(22.dp(), 16.dp(), 22.dp(), 16.dp())
        }
        if (ps5) box.addView(ps5Logo())
        box.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(label(if (ps5) "PS5" else name, if (ps5) 28f else 20f, true, INK))
            addView(label(if (connected) "Connected" else "No device", 14f, false, DIM))
        })
        card.addView(box, FrameLayout.LayoutParams(MATCH, MATCH))
        card.setOnClickListener { switchTo(info) }
        return card
    }

    /** Uses res/drawable/ps5.png if you add it; otherwise a plain "PS5" tile. */
    private fun ps5Logo(): View {
        val size = 112.dp()
        val frame = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(size, size).apply { rightMargin = 22.dp() }
            background = GradientDrawable().apply {
                cornerRadius = 24.dp().toFloat()
                setColor(Color.WHITE)
            }
            clipToOutline = true
        }
        val resId = resources.getIdentifier("ps5", "drawable", packageName)
        if (resId != 0) {
            frame.addView(ImageView(this).apply {
                setImageResource(resId)
                scaleType = ImageView.ScaleType.CENTER_CROP
            }, FrameLayout.LayoutParams(size, size))
        } else {
            frame.addView(label("PS5", 22f, true, NAVY).apply {
                gravity = Gravity.CENTER
            }, FrameLayout.LayoutParams(size, size))
        }
        return frame
    }

    private fun switchTo(info: TvInputInfo) {
        val intent = Intent(Intent.ACTION_VIEW, TvContract.buildChannelUriForPassthroughInput(info.id))
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            toast("Can't open this input")
        }
    }

    // ---------- All apps (every launchable app on the TV) ----------

    private fun loadApps() {
        val grid = findViewById<GridLayout>(R.id.appsGrid)
        grid.removeAllViews()
        grid.columnCount = 6
        val pm = packageManager
        val seen = HashSet<String>()
        listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)
            .flatMap { pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(it), 0) }
            .filter { it.activityInfo.packageName != packageName && seen.add(it.activityInfo.packageName) }
            .sortedBy { it.loadLabel(pm).toString().lowercase(Locale.getDefault()) }
            .forEach { grid.addView(appCard(it)) }
    }

    private fun appCard(ri: ResolveInfo): View {
        val pm = packageManager
        val pkg = ri.activityInfo.packageName
        val card = baseCard(230.dp(), 130.dp())
        val art = ri.activityInfo.loadBanner(pm) ?: ri.loadIcon(pm)
        card.addView(ImageView(this).apply {
            setImageDrawable(art)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(14.dp(), 14.dp(), 14.dp(), 34.dp())
        }, FrameLayout.LayoutParams(MATCH, MATCH))
        card.addView(label(ri.loadLabel(pm).toString(), 14f, true, INK).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER_HORIZONTAL
        }, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM).apply { bottomMargin = 8.dp() })
        card.setOnClickListener {
            val intent = pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg)
            if (intent == null) toast("Can't open this app") else startActivity(intent)
        }
        return card
    }

    // ---------- Shared views and D-pad focus ----------

    private fun label(text: String, sp: Float, bold: Boolean, color: Int) = TextView(this).apply {
        this.text = text
        textSize = sp
        setTextColor(color)
        if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
    }

    private fun baseCard(w: Int, h: Int): FrameLayout {
        val card = FrameLayout(this)
        card.layoutParams = ViewGroup.MarginLayoutParams(w, h).apply {
            setMargins(12.dp(), 12.dp(), 12.dp(), 12.dp())
        }
        card.isFocusable = true
        card.isClickable = true
        card.background = cardBackground(false)
        card.setOnFocusChangeListener { v, hasFocus ->
            v.background = cardBackground(hasFocus)
            val s = if (hasFocus) 1.06f else 1f
            v.animate().scaleX(s).scaleY(s).setDuration(180).start()
            v.elevation = if (hasFocus) 12f else 0f
        }
        return card
    }

    private fun cardBackground(focused: Boolean) = GradientDrawable().apply {
        cornerRadius = 24.dp().toFloat()
        setColor(if (focused) Color.parseColor("#1AFFFFFF") else Color.parseColor("#0BFFFFFF"))
        setStroke(if (focused) 3.dp() else 1.dp(), if (focused) GOLD else Color.parseColor("#14FFFFFF"))
    }
}
