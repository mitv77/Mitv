package com.example.mitvhome

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.Activity
import android.app.ActivityOptions
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.tv.TvContract
import android.media.tv.TvInputInfo
import android.media.tv.TvInputManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
private val PS5_REGEX = Regex("ps\\s?5|playstation", RegexOption.IGNORE_CASE)
private fun isPs5(name: String) = PS5_REGEX.containsMatchIn(name)

data class AppEntry(val label: String, val pkg: String, val art: Drawable?)

class InputUi(val card: View, val box: View, val sub: TextView, var state: Int)

/** A simple drawn console picture (own artwork, no brand logo). Add res/drawable/ps5.png to use a real photo. */
class ConsoleArt(ctx: Context) : View(ctx) {
    private val white = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val dark = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#0B1030") }
    private val blue = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#4C86FF") }
    private val r = RectF()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        r.set(w * 0.30f, h * 0.86f, w * 0.70f, h * 0.90f); c.drawRoundRect(r, h * 0.02f, h * 0.02f, blue)
        r.set(w * 0.40f, h * 0.12f, w * 0.60f, h * 0.84f); c.drawRoundRect(r, w * 0.06f, w * 0.06f, dark)
        r.set(w * 0.28f, h * 0.10f, w * 0.46f, h * 0.84f); c.drawRoundRect(r, w * 0.09f, w * 0.09f, white)
        r.set(w * 0.54f, h * 0.10f, w * 0.72f, h * 0.84f); c.drawRoundRect(r, w * 0.09f, w * 0.09f, white)
        r.set(w * 0.485f, h * 0.20f, w * 0.515f, h * 0.78f); c.drawRoundRect(r, w * 0.015f, w * 0.015f, blue)
    }
}

class MainActivity : Activity() {

    private val KEY_PS5 = "ps5_id"
    private val INK = Color.parseColor("#F1EBE0")
    private val DIM = Color.parseColor("#8C887F")
    private val GOLD = Color.parseColor("#E8BB72")
    private val GREEN = Color.parseColor("#6FD6A0")
    private val AMBER = Color.parseColor("#E8BB72")

    // Everything is sized for a 1920 px wide screen and scaled to the real TV screen.
    private var u = 1f
    private fun px(v: Float): Int = (v * u).toInt()

    private lateinit var scroller: ScrollView
    private lateinit var inputsScroll: HorizontalScrollView
    private lateinit var inputsRow: LinearLayout
    private lateinit var appsBox: LinearLayout
    private lateinit var clockView: TextView
    private lateinit var dateView: TextView
    private lateinit var sfx: Sfx

    private val tvm by lazy { getSystemService(TV_INPUT_SERVICE) as TvInputManager }
    private val prefs by lazy { getSharedPreferences("mitvv5", MODE_PRIVATE) }

    private val cards = ArrayList<View>()
    private val inputUis = LinkedHashMap<String, InputUi>()
    private var inputsKey = "#"
    private var appsSig = ""
    private var loadingApps = false
    private var tickCount = 0
    private val ambient = ArrayList<ObjectAnimator>()
    private var introInputs = false
    private var introApps = false
    private var firstResume = true

    private val handler = Handler(Looper.getMainLooper())

    // Once a second: refresh input states in place (no redraw, no flicker)
    private val ticker = object : Runnable {
        override fun run() {
            tickCount++
            updateInputs()
            if (tickCount % 15 == 0) updateClock()
            if (tickCount % 5 == 0) refreshApps()
            handler.postDelayed(this, 1000)
        }
    }

    // Instant updates when an HDMI device is plugged in/out or turned on/off
    private val tvCallback = object : TvInputManager.TvInputCallback() {
        override fun onInputStateChanged(inputId: String, state: Int) { updateInputs() }
        override fun onInputAdded(inputId: String) { updateInputs() }
        override fun onInputRemoved(inputId: String) { updateInputs() }
        override fun onInputUpdated(inputId: String) { updateInputs() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sfx = Sfx(this)
        val dm = resources.displayMetrics
        u = maxOf(dm.widthPixels, dm.heightPixels) / 1920f
        buildScreen()
    }

    override fun onResume() {
        super.onResume()
        // Coming back from an app: the home screen "zooms out" and fades in
        if (!firstResume) {
            scroller.alpha = 0f
            scroller.scaleX = 1.05f
            scroller.scaleY = 1.05f
            scroller.animate().alpha(1f).scaleX(1f).scaleY(1f)
                .setDuration(280).setInterpolator(DecelerateInterpolator(1.6f)).start()
        }
        firstResume = false
        for (a in ambient) { if (a.isStarted) a.resume() else a.start() }
        updateClock()
        updateInputs()
        refreshApps()
        try { tvm.registerCallback(tvCallback, handler) } catch (e: Exception) { }
        tickCount = 0
        handler.postDelayed(ticker, 1000)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
        for (a in ambient) a.pause()
        try { tvm.unregisterCallback(tvCallback) } catch (e: Exception) { }
    }

    override fun onDestroy() {
        super.onDestroy()
        sfx.release()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        scroller.smoothScrollTo(0, 0)
        cards.firstOrNull()?.requestFocus()
    }

    @Deprecated("Home screen should not close on Back")
    override fun onBackPressed() {
        // do nothing: this is the home screen
    }

    // ---------- Screen ----------

    private fun buildScreen() {
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor("#0A0B0E"))
        // Slow drifting light behind everything (cheap GPU layers)
        addGlow(root, px(1500f), Color.parseColor("#2AE8BB72"), Gravity.TOP or Gravity.END, -px(450f), -px(500f), px(140f).toFloat(), px(90f).toFloat(), 23000L)
        addGlow(root, px(1300f), Color.parseColor("#302A4AA8"), Gravity.BOTTOM or Gravity.START, -px(420f), -px(480f), px(120f).toFloat(), px(100f).toFloat(), 29000L)

        scroller = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            clipChildren = false
            clipToPadding = false
            isFocusable = false
            descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
            setPadding(px(88f), px(48f), px(88f), px(80f))
        }

        clockView = label("", 110f, false, INK).apply { typeface = Typeface.SERIF }
        dateView = label("", 30f, false, DIM)
        content.addView(clockView)
        content.addView(dateView)

        content.addView(label("Inputs", 44f, false, INK).apply {
            typeface = Typeface.SERIF
            setPadding(0, px(36f), 0, px(6f))
        })

        inputsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            clipChildren = false
            clipToPadding = false
        }
        inputsScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            clipChildren = false
            clipToPadding = false
            isFocusable = false
            descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
            setPadding(0, px(16f), 0, px(16f))
            addView(inputsRow, FrameLayout.LayoutParams(WRAP, WRAP))
        }
        content.addView(inputsScroll, LinearLayout.LayoutParams(MATCH, WRAP))

        content.addView(label("All apps", 44f, false, INK).apply {
            typeface = Typeface.SERIF
            setPadding(0, px(20f), 0, px(6f))
        })

        appsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
            setPadding(0, px(10f), 0, 0)
        }
        content.addView(appsBox, LinearLayout.LayoutParams(MATCH, WRAP))

        scroller.addView(content, FrameLayout.LayoutParams(MATCH, WRAP))
        root.addView(scroller, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)
        playIntro(listOf<View>(clockView, dateView)) { i -> i * 90L }
    }

    private fun updateClock() {
        val now = Date()
        clockView.text = SimpleDateFormat("h:mm", Locale.getDefault()).format(now)
        dateView.text = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun label(text: String, sizeDesignPx: Float, bold: Boolean, color: Int) = TextView(this).apply {
        this.text = text
        setTextSize(TypedValue.COMPLEX_UNIT_PX, px(sizeDesignPx).toFloat())
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        includeFontPadding = false
    }

    // ---------- Inputs (HDMI, AV, PS5 ...) ----------

    private fun updateInputs() {
        val savedPs5 = prefs.getString(KEY_PS5, null)
        val list = tvm.tvInputList
            .filter { it.isPassthroughInput || it.type == TvInputInfo.TYPE_HDMI }
            .map { info ->
                val name = (info.loadCustomLabel(this) ?: info.loadLabel(this)).toString()
                Triple(info, name, isPs5(name) || info.id == savedPs5)
            }
            .sortedByDescending { it.third }

        // Rebuild the cards only if the list itself changed (rare)
        val key = list.joinToString("|") { it.first.id + ":" + it.second + ":" + it.third }
        if (key != inputsKey) {
            inputsKey = key
            val keep = focusedIndex()
            inputsRow.removeAllViews()
            inputUis.clear()
            if (list.isEmpty()) inputsRow.addView(label("No inputs found", 30f, false, DIM))
            for ((info, name, ps5) in list) {
                val ui = inputCard(info, name, ps5)
                inputUis[info.id] = ui
                inputsRow.addView(ui.card)
            }
            collectCards(keep)
            if (!introInputs && inputUis.isNotEmpty()) {
                introInputs = true
                playIntro(inputUis.values.map { it.card }) { i -> 120L + i * 60L }
            }
        }

        // Otherwise just update the status text in place
        for ((info, _, _) in list) {
            val ui = inputUis[info.id] ?: continue
            val st = tvm.getInputState(info.id)
            if (ui.state != st) {
                ui.state = st
                applyState(ui, st)
            }
        }
    }

    private fun applyState(ui: InputUi, st: Int) {
        when (st) {
            TvInputManager.INPUT_STATE_CONNECTED -> {
                ui.sub.text = "Connected"
                ui.sub.setTextColor(GREEN)
                ui.box.alpha = 1f
            }
            TvInputManager.INPUT_STATE_CONNECTED_STANDBY -> {
                ui.sub.text = "Standby"
                ui.sub.setTextColor(AMBER)
                ui.box.alpha = 0.85f
            }
            else -> {
                ui.sub.text = "No device"
                ui.sub.setTextColor(DIM)
                ui.box.alpha = 0.6f
            }
        }
    }

    private fun inputCard(info: TvInputInfo, name: String, ps5: Boolean): InputUi {
        val card = baseCard(if (ps5) px(560f) else px(310f), px(210f))
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(px(30f), px(20f), px(30f), px(20f))
        }
        if (ps5) box.addView(ps5Logo())
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }
        col.addView(label(if (ps5) "PS5" else name, if (ps5) 60f else 44f, true, INK))
        val sub = label("", 28f, false, DIM).apply { setPadding(0, px(8f), 0, 0) }
        col.addView(sub)
        box.addView(col)
        card.addView(box, FrameLayout.LayoutParams(MATCH, MATCH))
        card.setOnClickListener { switchTo(info, card) }
        // Hold OK on any input to mark / unmark it as the PS5
        card.setOnLongClickListener {
            if (prefs.getString(KEY_PS5, null) == info.id) {
                prefs.edit().remove(KEY_PS5).apply()
                toast("PS5 tag removed")
            } else {
                prefs.edit().putString(KEY_PS5, info.id).apply()
                toast("$name marked as PS5")
            }
            sfx.select()
            updateInputs()
            true
        }
        return InputUi(card, box, sub, -1)
    }

    private fun ps5Logo(): View {
        val size = px(150f)
        val frame = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(size, size).apply { rightMargin = px(28f) }
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#2A4AA8"), Color.parseColor("#0B1433"))
            ).apply { cornerRadius = px(30f).toFloat() }
            clipToOutline = true
        }
        val resId = resources.getIdentifier("ps5", "drawable", packageName)
        if (resId != 0) {
            frame.addView(ImageView(this).apply {
                setImageResource(resId)
                scaleType = ImageView.ScaleType.CENTER_CROP
            }, FrameLayout.LayoutParams(size, size))
        } else {
            frame.addView(ConsoleArt(this), FrameLayout.LayoutParams(size, size))
        }
        return frame
    }

    private fun switchTo(info: TvInputInfo, card: View) {
        sfx.select()
        val intent = Intent(Intent.ACTION_VIEW, TvContract.buildChannelUriForPassthroughInput(info.id))
        launchWithZoom(card, intent)
    }

    // ---------- All apps ----------

    private fun refreshApps() {
        if (loadingApps) return
        loadingApps = true
        Thread {
            try {
                val pm = packageManager
                val seen = HashSet<String>()
                val infos: List<ResolveInfo> =
                    listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)
                        .flatMap { pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(it), 0) }
                        .filter { it.activityInfo.packageName != packageName && seen.add(it.activityInfo.packageName) }

                val sig = infos.map { it.activityInfo.packageName }.sorted().joinToString("|")
                if (sig == appsSig) return@Thread

                val entries = infos
                    .map { ri ->
                        val art: Drawable? = try {
                            ri.activityInfo.loadBanner(pm) ?: ri.loadIcon(pm)
                        } catch (e: Exception) {
                            null
                        }
                        AppEntry(ri.loadLabel(pm).toString(), ri.activityInfo.packageName, art)
                    }
                    .sortedBy { it.label.lowercase(Locale.getDefault()) }

                runOnUiThread {
                    if (isDestroyed) return@runOnUiThread
                    appsSig = sig
                    val keep = focusedIndex()
                    appsBox.removeAllViews()
                    for (chunk in entries.chunked(6)) {
                        val row = LinearLayout(this).apply {
                            orientation = LinearLayout.HORIZONTAL
                            clipChildren = false
                        }
                        for (e in chunk) row.addView(appCard(e))
                        appsBox.addView(row)
                    }
                    collectCards(keep)
                    if (!introApps) {
                        introApps = true
                        val views = ArrayList<View>()
                        for (r in 0 until appsBox.childCount) {
                            val row = appsBox.getChildAt(r) as ViewGroup
                            for (c in 0 until row.childCount) views.add(row.getChildAt(c))
                        }
                        playIntro(views) { i -> 250L + (i / 6) * 70L + (i % 6) * 40L }
                    }
                }
            } finally {
                loadingApps = false
            }
        }.start()
    }

    private fun appCard(e: AppEntry): View {
        val card = baseCard(px(270f), px(190f))
        if (e.art != null) {
            card.addView(ImageView(this).apply {
                setImageDrawable(e.art)
                scaleType = ImageView.ScaleType.FIT_CENTER
                setPadding(px(20f), px(18f), px(20f), px(62f))
            }, FrameLayout.LayoutParams(MATCH, MATCH))
        } else {
            // No icon available: show the first letter instead
            card.addView(label(e.label.take(1).uppercase(Locale.getDefault()), 72f, true, GOLD).apply {
                gravity = Gravity.CENTER
                setPadding(0, 0, 0, px(50f))
            }, FrameLayout.LayoutParams(MATCH, MATCH))
        }
        card.addView(label(e.label, 26f, true, INK).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER_HORIZONTAL
        }, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM).apply {
            bottomMargin = px(16f)
            leftMargin = px(10f)
            rightMargin = px(10f)
        })
        card.setOnClickListener {
            sfx.select()
            val pm = packageManager
            val intent = pm.getLeanbackLaunchIntentForPackage(e.pkg) ?: pm.getLaunchIntentForPackage(e.pkg)
            if (intent == null) toast("Can't open this app") else launchWithZoom(card, intent)
        }
        return card
    }

    // ---------- Animation helpers ----------

    /** Items rise up and fade in one after another. */
    private fun playIntro(views: List<View>, delayFor: (Int) -> Long) {
        val rise = px(36f).toFloat()
        views.forEachIndexed { i, v ->
            v.alpha = 0f
            v.translationY = rise
            ObjectAnimator.ofPropertyValuesHolder(
                v,
                PropertyValuesHolder.ofFloat(View.ALPHA, 0f, 1f),
                PropertyValuesHolder.ofFloat(View.TRANSLATION_Y, rise, 0f)
            ).apply {
                setStartDelay(delayFor(i))
                setDuration(430)
                setInterpolator(DecelerateInterpolator(1.8f))
                start()
            }
        }
    }

    /** Press-in squeeze, then the app opens by zooming out of the card. */
    private fun launchWithZoom(card: View, intent: Intent) {
        card.animate().cancel()
        card.animate().scaleX(0.94f).scaleY(0.94f).setDuration(80).withEndAction {
            try {
                val opts = ActivityOptions.makeScaleUpAnimation(card, 0, 0, card.width, card.height)
                startActivity(intent, opts.toBundle())
            } catch (e: Exception) {
                toast("Can't open this")
            }
            card.animate().scaleX(1.07f).scaleY(1.07f)
                .setDuration(240).setInterpolator(OvershootInterpolator(1.4f)).start()
        }.start()
    }

    private fun addGlow(
        root: FrameLayout, size: Int, color: Int, gravity: Int,
        mx: Int, my: Int, dx: Float, dy: Float, ms: Long
    ) {
        val v = View(this)
        v.background = GradientDrawable().apply {
            setGradientType(GradientDrawable.RADIAL_GRADIENT)
            setGradientRadius(size / 2f)
            setColors(intArrayOf(color, Color.TRANSPARENT))
        }
        v.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        root.addView(v, FrameLayout.LayoutParams(size, size, gravity).apply { setMargins(mx, my, mx, my) })
        listOf(
            ObjectAnimator.ofFloat(v, View.TRANSLATION_X, -dx, dx).apply { setDuration(ms) },
            ObjectAnimator.ofFloat(v, View.TRANSLATION_Y, -dy, dy).apply { setDuration(ms * 4 / 5) }
        ).forEach { a ->
            a.repeatCount = ValueAnimator.INFINITE
            a.repeatMode = ValueAnimator.REVERSE
            a.setInterpolator(AccelerateDecelerateInterpolator())
            ambient.add(a)
        }
    }

    // ---------- Cards, focus and scrolling ----------

    private fun baseCard(w: Int, h: Int): FrameLayout {
        val card = FrameLayout(this)
        val m = px(10f)
        card.layoutParams = LinearLayout.LayoutParams(w, h).apply { setMargins(m, m, m, m) }
        card.isFocusable = true
        card.isClickable = true
        card.isLongClickable = true
        card.background = cardBackground(false)
        card.clipToOutline = true

        // soft light that sweeps across the card when it gets focus
        val shine = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(0x00FFFFFF, 0x30FFFFFF, 0x00FFFFFF)
            )
            visibility = View.INVISIBLE
        }
        card.addView(shine, FrameLayout.LayoutParams((w * 0.5f).toInt(), MATCH))
        card.tag = shine

        card.setOnFocusChangeListener { v, hasFocus ->
            v.background = cardBackground(hasFocus)
            v.translationZ = if (hasFocus) 8f else 0f
            val sc = if (hasFocus) 1.07f else 1f
            v.animate().cancel()
            v.animate().scaleX(sc).scaleY(sc)
                .setDuration(if (hasFocus) 210L else 150L)
                .setInterpolator(if (hasFocus) OvershootInterpolator(1.8f) else DecelerateInterpolator())
                .start()
            val sh = v.tag as? View
            if (sh != null) {
                sh.animate().cancel()
                if (hasFocus) {
                    sh.bringToFront()
                    sh.visibility = View.VISIBLE
                    sh.translationX = -v.width * 0.5f
                    sh.animate().translationX(v.width.toFloat())
                        .setDuration(520)
                        .setInterpolator(AccelerateDecelerateInterpolator())
                        .withEndAction { sh.visibility = View.INVISIBLE }
                        .start()
                } else {
                    sh.visibility = View.INVISIBLE
                }
            }
            if (hasFocus) ensureVisible(v)
        }
        return card
    }

    private fun cardBackground(focused: Boolean) = GradientDrawable().apply {
        cornerRadius = px(26f).toFloat()
        setColor(if (focused) Color.parseColor("#26FFFFFF") else Color.parseColor("#12FFFFFF"))
        setStroke(
            if (focused) px(4f) else px(1f),
            if (focused) GOLD else Color.parseColor("#1EFFFFFF")
        )
    }

    private fun focusedIndex(): Int {
        val f = currentFocus ?: return -1
        return cards.indexOf(f)
    }

    private fun collectCards(restore: Int) {
        cards.clear()
        for (i in 0 until inputsRow.childCount) {
            val v = inputsRow.getChildAt(i)
            if (v.isFocusable) cards.add(v)
        }
        for (r in 0 until appsBox.childCount) {
            val row = appsBox.getChildAt(r) as ViewGroup
            for (c in 0 until row.childCount) cards.add(row.getChildAt(c))
        }
        if (cards.isEmpty()) return
        val target = if (restore in cards.indices) cards[restore] else cards[0]
        target.post { target.requestFocus() }
    }

    private fun ensureVisible(v: View) {
        val r = Rect()
        v.getDrawingRect(r)
        scroller.offsetDescendantRectToMyCoords(v, r)
        val margin = px(90f)
        val cur = scroller.scrollY
        var target = cur
        if (r.top - margin < cur) target = r.top - margin
        else if (r.bottom + margin > cur + scroller.height) target = r.bottom + margin - scroller.height
        target = target.coerceAtLeast(0)
        if (target != cur) scroller.smoothScrollTo(0, target)

        if (v.parent === inputsRow) {
            val r2 = Rect()
            v.getDrawingRect(r2)
            inputsScroll.offsetDescendantRectToMyCoords(v, r2)
            val m2 = px(88f)
            val cx = inputsScroll.scrollX
            var t2 = cx
            if (r2.left - m2 < cx) t2 = r2.left - m2
            else if (r2.right + m2 > cx + inputsScroll.width) t2 = r2.right + m2 - inputsScroll.width
            t2 = t2.coerceAtLeast(0)
            if (t2 != cx) inputsScroll.smoothScrollTo(t2, 0)
        }
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val dir = when (e.keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT -> 0
            KeyEvent.KEYCODE_DPAD_RIGHT -> 1
            KeyEvent.KEYCODE_DPAD_UP -> 2
            KeyEvent.KEYCODE_DPAD_DOWN -> 3
            else -> -1
        }
        if (dir >= 0) {
            if (e.action == KeyEvent.ACTION_DOWN) moveFocus(dir)
            return true
        }
        return super.dispatchKeyEvent(e)
    }

    private fun moveFocus(dir: Int) {
        val cur = currentFocus
        if (cur == null || !cards.contains(cur)) {
            cards.firstOrNull()?.requestFocus()
            return
        }
        val a = IntArray(2)
        cur.getLocationInWindow(a)
        val cx = a[0] + cur.width / 2
        val cy = a[1] + cur.height / 2

        var best: View? = null
        var bestScore = Long.MAX_VALUE
        val b = IntArray(2)
        for (c in cards) {
            if (c === cur) continue
            c.getLocationInWindow(b)
            val dx = b[0] + c.width / 2 - cx
            val dy = b[1] + c.height / 2 - cy
            var primary = 0
            var secondary = 0
            when (dir) {
                0 -> { if (dx >= -4) continue; primary = -dx; secondary = abs(dy) }
                1 -> { if (dx <= 4) continue; primary = dx; secondary = abs(dy) }
                2 -> { if (dy >= -4) continue; primary = -dy; secondary = abs(dx) }
                else -> { if (dy <= 4) continue; primary = dy; secondary = abs(dx) }
            }
            val score = primary.toLong() + secondary.toLong() * 3
            if (score < bestScore) {
                bestScore = score
                best = c
            }
        }
        if (best != null) {
            sfx.move()
            best.requestFocus()
        } else {
            sfx.bump()
        }
    }
}
