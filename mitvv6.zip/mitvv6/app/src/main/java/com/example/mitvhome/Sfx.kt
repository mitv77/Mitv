package com.example.mitvhome

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.SystemClock
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Soft UI sounds, generated in code (no audio files needed).
 * Set SOUND_ON to false to mute the whole app UI.
 */
class Sfx(ctx: Context) {

    companion object {
        const val SOUND_ON = true
        private const val RATE = 44100
    }

    private val pool: SoundPool = SoundPool.Builder()
        .setMaxStreams(4)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .build()

    private val ready = HashSet<Int>()
    private var moveId = 0
    private var selectId = 0
    private var bumpId = 0
    private var lastMove = 0L

    init {
        pool.setOnLoadCompleteListener { _, id, status -> if (status == 0) ready.add(id) }
        moveId = load(ctx, "move", synth(1500.0, 1500.0, 40, 0.30))
        selectId = load(ctx, "select", synth(700.0, 1150.0, 150, 0.45))
        bumpId = load(ctx, "bump", synth(240.0, 200.0, 70, 0.40))
    }

    fun move() {
        val now = SystemClock.uptimeMillis()
        if (now - lastMove < 55) return   // no machine-gun sound when holding a key
        lastMove = now
        play(moveId)
    }

    fun select() = play(selectId)

    fun bump() = play(bumpId)

    fun release() {
        pool.release()
    }

    private fun play(id: Int) {
        if (SOUND_ON && id in ready) pool.play(id, 1f, 1f, 1, 0, 1f)
    }

    private fun load(ctx: Context, name: String, samples: ShortArray): Int {
        val f = File(ctx.cacheDir, "sfx_$name.wav")
        f.writeBytes(wav(samples))
        return pool.load(f.absolutePath, 1)
    }

    // A short sine blip with a little 2nd harmonic, a soft attack and a smooth fade-out
    private fun synth(f1: Double, f2: Double, ms: Int, vol: Double): ShortArray {
        val n = RATE * ms / 1000
        val out = ShortArray(n)
        var phase = 0.0
        for (i in 0 until n) {
            val t = i.toDouble() / n
            val f = f1 + (f2 - f1) * t
            phase += 2.0 * Math.PI * f / RATE
            val attack = minOf(1.0, i / (RATE * 0.004))
            val decay = Math.exp(-4.5 * t)
            val s = (Math.sin(phase) + 0.3 * Math.sin(2.0 * phase)) / 1.3
            out[i] = (s * attack * decay * vol * Short.MAX_VALUE).toInt().toShort()
        }
        return out
    }

    private fun wav(samples: ShortArray): ByteArray {
        val dataLen = samples.size * 2
        val bb = ByteBuffer.allocate(44 + dataLen).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray())
        bb.putInt(36 + dataLen)
        bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray())
        bb.putInt(16)
        bb.putShort(1)            // PCM
        bb.putShort(1)            // mono
        bb.putInt(RATE)
        bb.putInt(RATE * 2)
        bb.putShort(2)
        bb.putShort(16)
        bb.put("data".toByteArray())
        bb.putInt(dataLen)
        for (s in samples) bb.putShort(s)
        return bb.array()
    }
}
