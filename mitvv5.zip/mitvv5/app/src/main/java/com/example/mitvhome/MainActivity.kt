package com.example.mitvhome

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.tv.TvContract
import android.media.tv.TvInputInfo
import android.media.tv.TvInputManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
private val PS5_REGEX = Regex("ps\\s?5|playstation", RegexOption.IGNORE_CASE)
private fun isPs5(name: String) = PS5_REGEX.containsMatchIn(name)

data class AppEntry(val label: String, val pkg: String, val art: Drawable?)

class MainActivity : Activity() {

    private val INK = Color.parseColor("#F1EBE0")
    private val DIM = Color.parseColor("#8C887F")
    private val GOLD = Color.parseColor("#E8BB72")
    private val GREEN = Color.parseColor("#6FD6A0")
    private val NAVY = Color.parseColor("#0A1640")

    // Everything is sized for a 1920 px wide screen and scaled to the real TV screen.
    private var u = 1f
    private fun px(v: Float): Int = (v * u).toInt()

    private lateinit var scroller: ScrollView
    private lateinit var inputsScroll: HorizontalScrollView
    private lateinit var inputsRow: LinearLayout
    private lateinit var appsBox: LinearLayout
    private lateinit var clockView: TextView
    private lateinit var dateView: TextView
    private lateinit var sfx: Sfx

    private val cards = ArrayList<View>()
    private var inputsSig = ""
    private var appsSig = ""
    private var loadingApps = false

    private val handler = Handler(Looper.getMainLooper())
    private val clockTick = object : Runnable {
        override fun run() {
            updateClock()
            handler.postDelayed(this, 15_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sfx = Sfx(this)
        val dm = resources.displayMetrics
        u = maxOf(dm.widthPixels, dm.heightPixels) / 1920f
        buildScreen()
    }

    override fun onResume() {
        super.onResume()
        handler.post(clockTick)
        refreshInputs()
        refreshApps()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(clockTick)
    }

    override fun onDestroy() {
        super.onDestroy()
        sfx.release()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        // Pressing Home again: go back to the top
        scroller.smoothScrollTo(0, 0)
        cards.firstOrNull()?.requestFocus()
    }

    @Deprecated("Home screen should not close on Back")
    override fun onBackPressed() {
        // do nothing: this is the home screen
    }

    // ---------- Screen ----------

    private fun buildScreen() {
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor("#0A0B0E"))

        scroller = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            clipChildren = false
            clipToPadding = false
            isFocusable = false
            descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
            setPadding(px(88f), px(48f), px(88f), px(80f))
        }

        clockView = label("", 110f, false, INK).apply { typeface = Typeface.SERIF }
        dateView = label("", 30f, false, DIM)
        content.addView(clockView)
        content.addView(dateView)

        content.addView(label("Inputs", 44f, false, INK).apply {
            typeface = Typeface.SERIF
            setPadding(0, px(36f), 0, px(6f))
        })

        inputsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            clipChildren = false
            clipToPadding = false
        }
        inputsScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            clipChildren = false
            clipToPadding = false
            isFocusable = false
            descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
            setPadding(0, px(16f), 0, px(16f))
            addView(inputsRow, FrameLayout.LayoutParams(WRAP, WRAP))
        }
        content.addView(inputsScroll, LinearLayout.LayoutParams(MATCH, WRAP))

        content.addView(label("All apps", 44f, false, INK).apply {
            typeface = Typeface.SERIF
            setPadding(0, px(20f), 0, px(6f))
        })

        appsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
            setPadding(0, px(10f), 0, 0)
        }
        content.addView(appsBox, LinearLayout.LayoutParams(MATCH, WRAP))

        scroller.addView(content, FrameLayout.LayoutParams(MATCH, WRAP))
        root.addView(scroller, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)
    }

    private fun updateClock() {
        val now = Date()
        clockView.text = SimpleDateFormat("h:mm", Locale.getDefault()).format(now)
        dateView.text = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun label(text: String, sizeDesignPx: Float, bold: Boolean, color: Int) = TextView(this).apply {
        this.text = text
        setTextSize(TypedValue.COMPLEX_UNIT_PX, px(sizeDesignPx).toFloat())
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        includeFontPadding = false
    }

    // ---------- Inputs (HDMI, AV, ...) ----------

    private fun refreshInputs() {
        val tvm = getSystemService(TV_INPUT_SERVICE) as TvInputManager
        val list = tvm.tvInputList
            .filter { it.isPassthroughInput }
            .map { Triple(it, it.loadLabel(this).toString(), tvm.getInputState(it.id) == TvInputManager.INPUT_STATE_CONNECTED) }
            .sortedByDescending { isPs5(it.second) }

        val sig = list.joinToString("|") { it.first.id + it.second + it.third }
        if (sig == inputsSig) return
        inputsSig = sig

        val keep = focusedIndex()
        inputsRow.removeAllViews()
        if (list.isEmpty()) {
            inputsRow.addView(label("No inputs found", 30f, false, DIM))
        }
        for ((info, name, connected) in list) {
            inputsRow.addView(inputCard(info, name, connected))
        }
        collectCards(keep)
    }

    private fun inputCard(info: TvInputInfo, name: String, connected: Boolean): View {
        val ps5 = isPs5(name)
        val card = baseCard(if (ps5) px(560f) else px(310f), px(210f))
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(px(30f), px(20f), px(30f), px(20f))
        }
        if (ps5) box.addView(ps5Logo())
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }
        col.addView(label(if (ps5) "PS5" else name, if (ps5) 60f else 44f, true, INK))
        col.addView(label(if (connected) "Connected" else "No device", 28f, false, if (connected) GREEN else DIM).apply {
            setPadding(0, px(8f), 0, 0)
        })
        box.addView(col)
        card.addView(box, FrameLayout.LayoutParams(MATCH, MATCH))
        card.alpha = if (connected) 1f else 0.65f
        card.setOnClickListener { switchTo(info) }
        return card
    }

    /** Uses res/drawable/ps5.png if you add it; otherwise a plain "PS5" tile. */
    private fun ps5Logo(): View {
        val size = px(150f)
        val frame = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(size, size).apply { rightMargin = px(28f) }
            background = GradientDrawable().apply {
                cornerRadius = px(30f).toFloat()
                setColor(Color.WHITE)
            }
            clipToOutline = true
        }
        val resId = resources.getIdentifier("ps5", "drawable", packageName)
        if (resId != 0) {
            frame.addView(ImageView(this).apply {
                setImageResource(resId)
                scaleType = ImageView.ScaleType.CENTER_CROP
            }, FrameLayout.LayoutParams(size, size))
        } else {
            frame.addView(label("PS5", 44f, true, NAVY).apply {
                gravity = Gravity.CENTER
            }, FrameLayout.LayoutParams(size, size))
        }
        return frame
    }

    private fun switchTo(info: TvInputInfo) {
        sfx.select()
        val intent = Intent(Intent.ACTION_VIEW, TvContract.buildChannelUriForPassthroughInput(info.id))
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            toast("Can't open this input")
        }
    }

    // ---------- All apps ----------

    private fun refreshApps() {
        if (loadingApps) return
        loadingApps = true
        Thread {
            try {
                val pm = packageManager
                val seen = HashSet<String>()
                val infos: List<ResolveInfo> =
                    listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)
                        .flatMap { pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(it), 0) }
                        .filter { it.activityInfo.packageName != packageName && seen.add(it.activityInfo.packageName) }

                val sig = infos.map { it.activityInfo.packageName }.sorted().joinToString("|")
                if (sig == appsSig) return@Thread

                val entries = infos
                    .map { ri ->
                        AppEntry(
                            ri.loadLabel(pm).toString(),
                            ri.activityInfo.packageName,
                            ri.activityInfo.loadBanner(pm) ?: ri.loadIcon(pm)
                        )
                    }
                    .sortedBy { it.label.lowercase(Locale.getDefault()) }

                runOnUiThread {
                    if (isDestroyed) return@runOnUiThread
                    appsSig = sig
                    val keep = focusedIndex()
                    appsBox.removeAllViews()
                    for (chunk in entries.chunked(6)) {
                        val row = LinearLayout(this).apply {
                            orientation = LinearLayout.HORIZONTAL
                            clipChildren = false
                        }
                        for (e in chunk) row.addView(appCard(e))
                        appsBox.addView(row)
                    }
                    collectCards(keep)
                }
            } finally {
                loadingApps = false
            }
        }.start()
    }

    private fun appCard(e: AppEntry): View {
        val card = baseCard(px(270f), px(190f))
        card.addView(ImageView(this).apply {
            setImageDrawable(e.art)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(px(20f), px(18f), px(20f), px(62f))
        }, FrameLayout.LayoutParams(MATCH, MATCH))
        card.addView(label(e.label, 26f, true, INK).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER_HORIZONTAL
        }, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM).apply {
            bottomMargin = px(16f)
            leftMargin = px(10f)
            rightMargin = px(10f)
        })
        card.setOnClickListener {
            sfx.select()
            val pm = packageManager
            val intent = pm.getLeanbackLaunchIntentForPackage(e.pkg) ?: pm.getLaunchIntentForPackage(e.pkg)
            if (intent == null) toast("Can't open this app") else startActivity(intent)
        }
        return card
    }

    // ---------- Cards, focus and scrolling ----------

    private fun baseCard(w: Int, h: Int): FrameLayout {
        val card = FrameLayout(this)
        val m = px(10f)
        card.layoutParams = LinearLayout.LayoutParams(w, h).apply { setMargins(m, m, m, m) }
        card.isFocusable = true
        card.isClickable = true
        card.background = cardBackground(false)
        card.setOnFocusChangeListener { v, hasFocus ->
            v.background = cardBackground(hasFocus)
            val s = if (hasFocus) 1.07f else 1f
            v.animate().scaleX(s).scaleY(s).setDuration(110).start()
            v.translationZ = if (hasFocus) 8f else 0f
            if (hasFocus) ensureVisible(v)
        }
        return card
    }

    private fun cardBackground(focused: Boolean) = GradientDrawable().apply {
        cornerRadius = px(26f).toFloat()
        setColor(if (focused) Color.parseColor("#26FFFFFF") else Color.parseColor("#12FFFFFF"))
        setStroke(
            if (focused) px(4f) else px(1f),
            if (focused) GOLD else Color.parseColor("#1EFFFFFF")
        )
    }

    private fun focusedIndex(): Int {
        val f = currentFocus ?: return -1
        return cards.indexOf(f)
    }

    private fun collectCards(restore: Int) {
        cards.clear()
        for (i in 0 until inputsRow.childCount) cards.add(inputsRow.getChildAt(i))
        for (r in 0 until appsBox.childCount) {
            val row = appsBox.getChildAt(r) as ViewGroup
            for (c in 0 until row.childCount) cards.add(row.getChildAt(c))
        }
        if (cards.isEmpty()) return
        val target = if (restore in cards.indices) cards[restore] else cards[0]
        target.post { target.requestFocus() }
    }

    private fun ensureVisible(v: View) {
        // vertical
        val r = Rect()
        v.getDrawingRect(r)
        scroller.offsetDescendantRectToMyCoords(v, r)
        val margin = px(90f)
        val cur = scroller.scrollY
        var target = cur
        if (r.top - margin < cur) target = r.top - margin
        else if (r.bottom + margin > cur + scroller.height) target = r.bottom + margin - scroller.height
        target = target.coerceAtLeast(0)
        if (target != cur) scroller.smoothScrollTo(0, target)

        // horizontal (inputs row only)
        if (v.parent === inputsRow) {
            val r2 = Rect()
            v.getDrawingRect(r2)
            inputsScroll.offsetDescendantRectToMyCoords(v, r2)
            val m2 = px(88f)
            val cx = inputsScroll.scrollX
            var t2 = cx
            if (r2.left - m2 < cx) t2 = r2.left - m2
            else if (r2.right + m2 > cx + inputsScroll.width) t2 = r2.right + m2 - inputsScroll.width
            t2 = t2.coerceAtLeast(0)
            if (t2 != cx) inputsScroll.smoothScrollTo(t2, 0)
        }
    }

    // D-pad: pick the nearest card in the pressed direction (works on the first press)
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val dir = when (e.keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT -> 0
            KeyEvent.KEYCODE_DPAD_RIGHT -> 1
            KeyEvent.KEYCODE_DPAD_UP -> 2
            KeyEvent.KEYCODE_DPAD_DOWN -> 3
            else -> -1
        }
        if (dir >= 0) {
            if (e.action == KeyEvent.ACTION_DOWN) moveFocus(dir)
            return true
        }
        return super.dispatchKeyEvent(e)
    }

    private fun moveFocus(dir: Int) {
        val cur = currentFocus
        if (cur == null || !cards.contains(cur)) {
            cards.firstOrNull()?.requestFocus()
            return
        }
        val a = IntArray(2)
        cur.getLocationInWindow(a)
        val cx = a[0] + cur.width / 2
        val cy = a[1] + cur.height / 2

        var best: View? = null
        var bestScore = Long.MAX_VALUE
        val b = IntArray(2)
        for (c in cards) {
            if (c === cur) continue
            c.getLocationInWindow(b)
            val dx = b[0] + c.width / 2 - cx
            val dy = b[1] + c.height / 2 - cy
            var primary = 0
            var secondary = 0
            when (dir) {
                0 -> { if (dx >= -4) continue; primary = -dx; secondary = abs(dy) }
                1 -> { if (dx <= 4) continue; primary = dx; secondary = abs(dy) }
                2 -> { if (dy >= -4) continue; primary = -dy; secondary = abs(dx) }
                else -> { if (dy <= 4) continue; primary = dy; secondary = abs(dx) }
            }
            val score = primary.toLong() + secondary.toLong() * 3
            if (score < bestScore) {
                bestScore = score
                best = c
            }
        }
        if (best != null) {
            sfx.move()
            best.requestFocus()
        } else {
            sfx.bump()
        }
    }
}
